import {WeatherItem} from "./item/weather-item";

export const WEATHER_ITEMS: WeatherItem[] = [];
