# Weather App Angular
## View Demo http://embed.plnkr.co/OZemYUWkWlf6lhSe8AC6/?show=preview
* Search city by name.
* Add city to the list.
* Retrieve weather data from public API service http://openweathermap.org/
* Display city weather data.
* Save city list as profile. Delete profiles.
* Load city weather data from saved profiles.